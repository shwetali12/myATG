from django.db import models

from django.contrib.auth.models import AbstractUser,Group, Permission
from django.utils.translation import gettext as _
from django.contrib.auth.models import AbstractUser,User
from datetime import datetime, date, timedelta

from app.models import User


class User(AbstractUser):
    # Custom fields
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)

    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True)
    username = models.CharField(max_length=100 ,unique=True)
    address_line1 = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.IntegerField(null=True)
    is_doctor = models.BooleanField('Is doctor',default=False)
    is_patient = models.BooleanField('Is patient',default=False)
    groups = models.ManyToManyField(Group, verbose_name=_('groups'), blank=True, related_name='app_user_groups')
    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name=_('user permissions'),
        blank=True,
        related_name='app_user_permissions'
    )


class Category(models.Model):
    name = models.CharField(max_length=20)

    def __str__(self):
        return self.name


class BlogPost(models.Model):
    Title = models.CharField(max_length=100)
    Image = models.ImageField(upload_to='blog_images')
    Category = models.ForeignKey(Category, on_delete=models.CASCADE)
    Summary = models.TextField(max_length=200)
    Content = models.TextField(max_length=200)
    is_draft = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.Title
 

class Doctor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,related_name="doctor_profile")
    profile_picture = models.ImageField(upload_to='profile_pictures/')
    speciality = models.CharField(max_length=100)

    def __str__(self):
        return self.user.get_full_name()

class Appointment(models.Model):
    doctor = models.ForeignKey(User, related_name='appointments_as_doctor', on_delete=models.CASCADE, limit_choices_to={'is_doctor': True})
    patient = models.ForeignKey(User, related_name='appointments_as_patient', on_delete=models.CASCADE, limit_choices_to={'is_patient': True})
    speciality = models.CharField(max_length=100)
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()

    def save(self, *args, **kwargs):
        self.end_time = (datetime.combine(date.min, self.start_time) + timedelta(minutes=45)).time()
        super(Appointment, self).save(*args, **kwargs)